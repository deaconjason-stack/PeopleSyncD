# CareSyncD v3 - Full Hospital Shift Simulator

CareSyncD v3 is a dependency-free browser-based clinical education simulator. v3 expands the v2 multi-patient engine into a compressed hospital shift where patient care competes with time-sensitive tasks, interruptions, admissions, staffing changes, delegation, new orders, family/provider communication and end-of-shift handoff.

> **Educational simulation only.** CareSyncD is not a medical device and must not be used to diagnose, monitor, or treat real patients. Scenario content requires qualified clinical and educational review before institutional use.

## Start locally

### Windows
Double-click `start-windows.bat`.

### macOS / Linux
```bash
chmod +x start-mac-linux.sh
./start-mac-linux.sh
```

### Any platform
```bash
npm start
```
Then open **http://localhost:3000**. Node.js 20+ is required. There are no third-party runtime dependencies.

## What is new in v3

- Full compressed hospital-day simulation: one real second represents one simulated shift minute
- Three hospital shifts, including the new **Full Hospital Day** mastery experience
- Dynamic admissions that add patients while the shift is already running
- Timed shift task board with due times, priorities, completion status and audit trail
- Delayed-care consequences that can reduce operational score and worsen simulated patient state
- Call lights, family questions, provider callbacks and other interruptions
- Staffing availability changes during the shift
- Scope-aware delegation to eligible available team members
- New provider orders injected during the shift
- Discharge/transfer planning tasks
- End-of-shift SBAR handoff window for every active patient
- Live handoff board with current vitals, diagnosis, pending priorities and disposition
- Separate clinical score and operations score combined into the total shift score
- Shift achievements such as Shift Commander, Operational Excellence and Nothing Fell Through
- Expanded debrief with patient results and a task audit

## Clinical content retained from v2

- 8 evolving clinical missions: hypoxia, dehydration/hypotension, hypoglycemia, sepsis, acute stroke, anaphylaxis, opioid-induced respiratory depression and cardiac arrest
- Guided, Standard and Challenge difficulty modes
- Time-dependent deterioration and surprise events
- Action sequencing consequences
- Clinical actions across assessment, airway, intervention, emergency response, communication and reassessment
- Contextual hints in Guided/Standard mode; no hints in Challenge mode
- Clinical notes, SBAR and reassessment actions
- Domain scoring for assessment, intervention, safety, communication and reassessment
- Achievements, XP, career ranks and run history
- Responsive browser simulation cockpit and live telemetry
- Instructor pause/resume/end controls
- Built-in HTTP/WebSocket server without Express or ws
- Docker, Railway and Procfile deployment configuration

## v3 hospital shifts

### Med-Surg Pressure Shift
A compressed 8-hour assignment with three evolving patients, rounding, call lights, family communication, staffing interruptions and end-of-shift handoff.

### High-Acuity Cross-Cover
An expert shift with competing time-sensitive emergencies, provider calls, monitor alarms, transport coordination and reduced respiratory-therapy availability.

### Full Hospital Day
A mastery shift with initial assignments plus new admissions, medication windows, family questions, new orders, staff reassignments, discharge planning, reassessment deadlines and full handoff.

## API highlights

- `GET /api/health`
- `GET /api/scenarios`
- `GET /api/profile?learner=<name>`
- `GET /api/sessions/history`
- `POST /api/sessions`
- `GET /api/sessions/:id`
- `POST /api/sessions/:id/actions`
- `POST /api/sessions/:id/select-patient`
- `POST /api/sessions/:id/hint`
- `POST /api/sessions/:id/notes`
- `POST /api/sessions/:id/tasks` - complete or delegate shift tasks
- `POST /api/sessions/:id/control`
- WebSocket: `/ws?sessionId=<id>`

## Test

```bash
npm test
npm run check
```

The v3 regression suite covers patient physiology, sequencing, hints, dynamic events, shift clock behavior, admissions, delegation, missed-task consequences, task-to-clinical-action linking, handoff generation, HTTP APIs and WebSocket transport.

## Production path

This v3 package is a functional education/training application and demonstration platform. Institution-grade deployment should add external database storage, identity/SSO, granular authorization, audit-log retention, backups, privacy/security review, accessibility validation, clinical content governance, scenario validation, faculty authoring tools, analytics/roster administration and formal educational validation. No FDA clearance, accreditation or clinical efficacy claim is made.
