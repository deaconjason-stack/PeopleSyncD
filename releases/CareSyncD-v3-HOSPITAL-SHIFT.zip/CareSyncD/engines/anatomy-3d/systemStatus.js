module.exports = function systemStatus(vitals){
  return {
    cardiovascular: vitals.systolicBP === 0 ? 'No perfusing pressure' : vitals.systolicBP < 90 ? 'Low perfusion' : 'Perfusing',
    respiratory: vitals.spo2 < 90 ? 'Compromised' : 'Supported',
    neurologic: vitals.glucose < 60 ? 'At risk' : 'Responsive',
    metabolic: vitals.temperature >= 38 ? 'Inflammatory stress' : 'Stable'
  };
};
