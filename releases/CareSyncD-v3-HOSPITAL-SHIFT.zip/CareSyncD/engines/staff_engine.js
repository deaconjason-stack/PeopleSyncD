module.exports={defaultStaff:()=>[{name:'Dr. Adams',role:'Physician'},{name:'Nurse Kelly',role:'RN'},{name:'Alex Rivera',role:'Respiratory Therapist'}]};
