// Capability helper for future immersive modules. The core CareSyncD training UI does not require VR.
async function detectWebXR(navigatorObject){
  const xr = navigatorObject && navigatorObject.xr;
  if (!xr || typeof xr.isSessionSupported !== 'function') return {available:false, immersiveVR:false};
  try { return {available:true, immersiveVR:await xr.isSessionSupported('immersive-vr')}; }
  catch { return {available:true, immersiveVR:false}; }
}
module.exports={detectWebXR};
