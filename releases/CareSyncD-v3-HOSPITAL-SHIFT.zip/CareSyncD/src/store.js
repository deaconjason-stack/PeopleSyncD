const fs=require('fs'); const path=require('path');
class Store{
 constructor(file){this.file=path.resolve(file||'./data/sessions.json'); fs.mkdirSync(path.dirname(this.file),{recursive:true}); if(!fs.existsSync(this.file)) fs.writeFileSync(this.file,'[]');}
 append(summary){let rows=[]; try{rows=JSON.parse(fs.readFileSync(this.file,'utf8'))}catch{} rows.push(summary); rows=rows.slice(-500); fs.writeFileSync(this.file,JSON.stringify(rows,null,2));}
 list(){try{return JSON.parse(fs.readFileSync(this.file,'utf8'))}catch{return []}}
}
module.exports={Store};
