const test=require('node:test');
const assert=require('node:assert/strict');
const {SimulationSession}=require('../src/simulation');
const {publicScenarios}=require('../src/scenarios');
const {ShiftSession,publicShifts}=require('../src/shift');

test('v3 catalog loads eight scenarios and three hospital shifts',()=>{
  assert.equal(publicScenarios().length,8);
  assert.equal(publicShifts().length,3);
  assert.ok(publicShifts().some(x=>x.id==='hospital_day'));
});

test('hypoxia airway and oxygen improve saturation',()=>{
  const s=new SimulationSession({scenarioId:'hypoxia'});const before=s.patient.vitals.spo2;
  s.action('assess');s.action('airway');const r=s.action('oxygen');
  assert.equal(r.ok,true);assert.ok(s.patient.vitals.spo2>before);assert.ok(s.score>0);
});

test('sequence mistakes generate feedback',()=>{
  const s=new SimulationSession({scenarioId:'dehydration'});const r=s.action('iv_fluids');
  assert.match(r.message,/IV Access/i);assert.ok(s.feedback.some(x=>/sequence|IV access/i.test(x.text)));
});

test('cardiac arrest CPR then shock restores pulse',()=>{
  const s=new SimulationSession({scenarioId:'cardiac_arrest'});s.action('call_code');s.action('cpr');s.action('monitor');s.action('defibrillate');assert.ok(s.patient.vitals.heartRate>0);
});

test('guided hint identifies a pending priority and costs points safely',()=>{
  const s=new SimulationSession({scenarioId:'sepsis',difficulty:'guided'});s.action('assess');const before=s.score;const h=s.hint();assert.equal(h.ok,true);assert.ok(h.message.length>10);assert.ok(s.score<=before);
});

test('challenge mode disables hints',()=>{const s=new SimulationSession({scenarioId:'stroke',difficulty:'challenge'});assert.equal(s.hint().ok,false)});

test('unexpected patient event fires as time advances',()=>{
  const s=new SimulationSession({scenarioId:'hypoxia'});for(let i=0;i<46;i++)s.tick();assert.ok(s.triggeredEvents.includes('fatigue'));
});

test('shift clock advances as a compressed hospital day',()=>{
  const sh=new ShiftSession({shiftId:'hospital_day'});assert.equal(sh.clock(),'07:00');for(let i=0;i<75;i++)sh.tick();assert.equal(sh.clock(),'08:15');
});

test('full hospital day adds a new admission dynamically',()=>{
  const sh=new ShiftSession({shiftId:'hospital_day'});const before=sh.patientSessions.length;for(let i=0;i<78;i++)sh.tick();assert.equal(before,3);assert.equal(sh.patientSessions.length,4);assert.ok(sh.patientSessions.some(p=>p.scenario.id==='sepsis'));
});

test('shift interruption can be delegated to eligible available staff',()=>{
  const sh=new ShiftSession({shiftId:'hospital_day'});for(let i=0;i<48;i++)sh.tick();const task=sh.tasks.find(t=>/bathroom request/i.test(t.title));assert.ok(task);const r=sh.taskCommand(task.id,'delegate','tech-1');assert.equal(r.ok,true);assert.equal(task.status,'delegated');for(let i=0;i<8;i++)sh.tick();assert.equal(task.status,'completed');
});

test('missed timed care reduces operations score and is auditable',()=>{
  const sh=new ShiftSession({shiftId:'med_surg'});for(let i=0;i<90;i++)sh.tick();assert.ok(sh.operationsScore<100);assert.ok(sh.tasks.some(t=>t.status==='missed'));assert.ok(sh.events.some(e=>/Missed task/i.test(e.text)));
});

test('clinical action automatically closes linked shift task',()=>{
  const sh=new ShiftSession({shiftId:'med_surg'});const p=sh.patientSessions[0];const task=sh.tasks.find(t=>t.patientId===p.id&&t.clinicalAction==='assess');assert.equal(task.status,'open');sh.action('assess',p.id);assert.equal(task.status,'completed');
});

test('handoff window creates SBAR tasks and live handoff summaries',()=>{
  const sh=new ShiftSession({shiftId:'high_acuity'});for(let i=0;i<360;i++)sh.tick();const handoffTasks=sh.tasks.filter(t=>t.category==='handoff');assert.equal(handoffTasks.length,sh.patientSessions.length);assert.equal(sh.handoff().length,sh.patientSessions.length);assert.ok(handoffTasks.every(t=>t.clinicalAction==='sbar'));
});

test('instructor controls pause and resume',()=>{const s=new SimulationSession({scenarioId:'sepsis',role:'instructor'});s.pause();assert.equal(s.status,'paused');s.resume();assert.equal(s.status,'running')});

test('HTTP API, hospital-shift task endpoint and WebSocket work end-to-end',async t=>{
  const {server,sessions}=require('../server/app');
  await new Promise((resolve,reject)=>{server.once('error',reject);server.listen(0,'127.0.0.1',resolve)});
  t.after(()=>new Promise(resolve=>server.close(resolve)));
  const port=server.address().port;
  const health=await fetch(`http://127.0.0.1:${port}/api/health`).then(r=>r.json());assert.equal(health.ok,true);assert.equal(health.version,'3.0.0');
  const catalog=await fetch(`http://127.0.0.1:${port}/api/scenarios`).then(r=>r.json());assert.equal(catalog.scenarios.length,8);assert.equal(catalog.shifts.length,3);
  const created=await fetch(`http://127.0.0.1:${port}/api/sessions`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({kind:'shift',shiftId:'hospital_day',learnerName:'Automated Test',role:'student',difficulty:'guided'})}).then(r=>r.json());
  assert.equal(created.session.shift.id,'hospital_day');
  const engine=sessions.get(created.session.id);for(let i=0;i<48;i++)engine.tick();
  const delegationTask=engine.tasks.find(t=>/bathroom request/i.test(t.title));assert.ok(delegationTask);
  const taskResult=await fetch(`http://127.0.0.1:${port}/api/sessions/${created.session.id}/tasks`,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({taskId:delegationTask.id,command:'delegate',staffId:'tech-1'})}).then(r=>r.json());assert.equal(taskResult.result.ok,true);
  const state=await new Promise((resolve,reject)=>{const ws=new WebSocket(`ws://127.0.0.1:${port}/ws?sessionId=${created.session.id}`);const timer=setTimeout(()=>{ws.close();reject(new Error('WebSocket timeout'))},2500);ws.onmessage=e=>{clearTimeout(timer);const msg=JSON.parse(e.data);ws.close();resolve(msg)};ws.onerror=()=>{clearTimeout(timer);reject(new Error('WebSocket error'))}});
  assert.equal(state.type,'state');assert.equal(state.state.shift.id,'hospital_day');assert.ok(Array.isArray(state.state.tasks));
});
