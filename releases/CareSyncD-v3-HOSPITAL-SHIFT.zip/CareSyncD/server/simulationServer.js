require('./app');
const {server}=require('./app');
const PORT=Number(process.env.PORT||3000),HOST=process.env.HOST||'0.0.0.0';
if(!server.listening)server.listen(PORT,HOST,()=>console.log(`CareSyncD v2 running at http://localhost:${PORT}`));
