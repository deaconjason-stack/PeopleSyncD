#!/usr/bin/env sh
cd "$(dirname "$0")/../.."
exec ./start-mac-linux.sh
