@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul || (echo Node.js 20+ is required. Install Node.js first. & pause & exit /b 1)
echo Starting CareSyncD...
call npm start
